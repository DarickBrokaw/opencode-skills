---
name: autodesk-revit-dynamo-launcher
description: Launches Revit 2024, opens a specific template, and automatically launches Dynamo using a Journal file.
metadata:
  short-description: Launch Revit 2024 + Template + Dynamo
---

# Autodesk Revit Dynamo Launcher

## Description
This skill combines the template-opening capability of `autodesk-revit-launcher` with the automation of `revit-dynamo-journal`.

## Actions
1.  Resolves the absolute path to the bundled `2024templaterevitskill.rte`.
2.  Generates a Revit Journal file on the fly, injecting the template path.
3.  Launches Revit 2024 with the journal.
4.  The Journal:
    *   Opens the template (selecting "New Project" to bypass the dialog).
    *   Switches to the "Manage" tab.
    *   Launches Dynamo.

## Usage
Run the PowerShell script:

```powershell
powershell -ExecutionPolicy Bypass -File "scripts\launch.ps1"
```

## Requirements
- Revit 2024 installed at default location.
- Dynamo for Revit installed.
