# Troubleshooting Guide (Auto-Generated)

This document contains known issues, solutions, and workarounds discovered through learning sessions. It is automatically updated by the `skill-retrospective-learner` skill.

## Generated from Learning Sessions

This section is populated automatically based on learning sessions. Do not edit manually - edits will be overwritten.

---

## Quick Reference

| charmap codec can't encode characters in position ... |
| Issue | Quick Fix |
|-------|-----------|
| Unicode encoding error | Use Node.js or `encoding='utf-8'` in subprocess |
| PowerShell blocked | Use `node run_ralph_node.js` instead |
| Plugin is placeholder | Copy from global: `%APPDATA%\opencode\plugins\` |
| Ruff permission error | Use `python -m ruff` instead of `ruff.exe` |
| Venv activation fails | Use direct paths: `.venv\Scripts/python.exe` |
| Git line ending warnings | `git config core.autocrlf input` |

---

## Encoding Issues

### 'charmap codec can't encode/decode'

**Category:** encoding  
**Severity:** high  
**Solution:** Use explicit UTF-8 encoding in subprocess calls

```python
# Python subprocess - always specify encoding
subprocess.run(cmd, encoding='utf-8', text=True)

# Node.js child_process - default is UTF-8
child_process.spawn(cmd[0], cmd.slice(1))
```

**Prevention Rule:** Always use explicit UTF-8 encoding for file I/O and subprocess calls on Windows.

---

## Permission Issues

### PermissionError: [WinError 5] Access is denied

**Category:** permissions  
**Severity:** high  
**Solution:** Use Python module invocation instead of direct executables

```bash
# Instead of:
ruff.exe check .

# Use:
python -m ruff check .
```

**Prevention Rule:** Use `python -m <tool>` for ruff, pytest, pip, and other executables on Windows.

---

## Plugin Issues

### Plugin is placeholder/stub

**Category:** plugin  
**Severity:** high  
**Solution:** Copy from global plugin location

**Global Plugin Location:**
```
%APPDATA%\opencode\plugins\<plugin-name>\.opencode\plugins\<plugin-name>.ts
```

**Example for ralph-loop:**
```bash
cp /c/Users/<user>/.config/opencode/plugins/ralph-loop/.opencode/plugins/ralph-loop.ts .opencode/plugins/ralph-loop.ts
```

**Prevention Rule:** Always check global plugins when local is missing or stub.

---

## PowerShell Issues

### PowerShell scripts blocked

**Category:** platform  
**Severity:** medium  
**Solution:** Use Node.js runner instead of PowerShell

**Node.js automation:**
```bash
node run_ralph_node.js build 5
```

**Alternative:** Use batch files with UTF-8 encoding:
```batch
chcp 65001
python script.py
```

**Prevention Rule:** Assume PowerShell scripts will be blocked by ThreatLocker or Execution Policy. Use Node.js for Windows automation.

---

## Virtual Environment Issues

### Venv activation fails in bash

**Category:** platform  
**Severity:** low  
**Solution:** Use direct venv paths

```bash
# Instead of:
.venv\Scripts\Activate.ps1
source .venv/bin/activate

# Use direct paths:
.venv\Scripts/python.exe -m pytest
.venv/Scripts/python.exe -m ruff check .
```

**Prevention Rule:** Use direct venv paths instead of activation scripts for cross-shell compatibility.

---

## Git Line Ending Issues

### LF will be replaced by CRLF

**Category:** platform  
**Severity:** low  
**Solution:** Configure git line ending handling

```bash
# Option 1: Input mode (recommended for Windows)
git config core.autocrlf input

# Option 2: Disable auto-conversion
git config core.autocrlf false
```

**Prevention Rule:** Set git config before first commit to avoid LF/CRLF warnings.

---

## Learning Session Log

### Session: 2026-01-21 - Windows Execution Barriers

**Goal:** Run Ralph-loop automated testing

**Blockers:**
- Plugin location confusion (30 min)
- Windows character encoding (2+ hours)
- PowerShell execution barriers (1 hour)
- Ruff executable permissions (30 min)
- Venv activation issues (15 min)

**Workarounds Applied:**
- Copy plugin from global location
- Use Node.js child_process for subprocess
- Create `run_ralph_node.js` automation script
- Use `python -m ruff` instead of `ruff.exe`
- Use direct venv paths

**Lessons Learned:**
- Windows requires explicit UTF-8 encoding everywhere
- PowerShell scripts are heavily blocked by security software
- Module invocation is more reliable than direct executables
- Global plugins should be checked first

**Rules Generated:**
1. Check global plugins when local is missing
2. Always use explicit UTF-8 encoding
3. Use `python -m <tool>` instead of executables
4. Use Node.js for Windows automation

---

## Platform-Specific Guidelines

### Windows

- Use explicit UTF-8 encoding in all I/O
- Avoid Unicode box-drawing characters in output
- Use `python -m <tool>` for ruff, pytest, pip
- Use Node.js for automation scripts
- Check global plugins first
- Use direct venv paths

### macOS/Linux

- Standard UTF-8 support is default
- Executables in venv work normally
- Shell activation scripts work
- Git line endings usually not an issue
- Local plugins are typically complete

---

## Auto-Generation Notice

This document is auto-generated by `skill-retrospective-learner`. To add entries:

1. Run a learning session: "Run the learning skill"
2. Answer the questions about your blocker/solution
3. The skill will automatically update this document

Do not edit manually - your changes may be overwritten.

---

*Last auto-generated: 2026-01-21*
*Generated by: skill-retrospective-learner v1.0.0*
