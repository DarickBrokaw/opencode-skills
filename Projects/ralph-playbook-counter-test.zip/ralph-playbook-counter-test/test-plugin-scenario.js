#!/usr/bin/env node
/**
 * Retrospective Plugin Test Scenario
 * 
 * This script tests the retrospective learning plugin by:
 * 1. Setting up the test environment
 * 2. Triggering a failure that the plugin should capture
 * 3. Verifying the plugin updated documentation correctly
 * 
 * Usage: node test-plugin-scenario.js
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const PROJECT_DIR = '/c/Users/darick/.config/opencode/Projects/ralph-playbook-counter-test';

console.log('='.repeat(70));
console.log('RETROSPECTIVE PLUGIN - TEST SCENARIO');
console.log('='.repeat(70));
console.log('');

// Test Setup
console.log('[SETUP] Preparing test environment...');

// Backup AGENTS.md and RUN_REPORT.md
const agentsPath = path.join(PROJECT_DIR, 'AGENTS.md');
const reportPath = path.join(PROJECT_DIR, 'RUN_REPORT.md');
const tsPath = path.join(PROJECT_DIR, 'TROUBLESHOOTING.md');

const backupAgents = fs.existsSync(agentsPath) ? fs.readFileSync(agentsPath, 'utf-8') : null;
const backupReport = fs.existsSync(reportPath) ? fs.readFileSync(reportPath, 'utf-8') : null;
const backupTs = fs.existsSync(tsPath) ? fs.readFileSync(tsPath, 'utf-8') : null;

console.log('✅ Backed up existing documentation');
console.log('');

// Record line counts before
const agentsLinesBefore = backupAgents ? backupAgents.split('\n').length : 0;
const reportLinesBefore = backupReport ? backupReport.split('\n').length : 0;

// Test 1: Trigger Encoding Error
console.log('[TEST 1] Triggering encoding error...');
console.log('-'.repeat(70));

try {
  // This should fail with an encoding error
  execSync('python -c "import subprocess; subprocess.run([\'echo\', \'test\'], encoding=\'invalid\')"', {
    cwd: PROJECT_DIR,
    encoding: 'utf-8',
    timeout: 10000
  });
  console.log('⚠️  Command succeeded (unexpected)');
} catch (error) {
  console.log('✅ Command failed as expected');
  console.log(`   Error: ${error.message.substring(0, 100)}...`);
}
console.log('');

// Test 2: Trigger Permission Error
console.log('[TEST 2] Triggering permission error...');
console.log('-'.repeat(70));

try {
  // This might fail with permission error
  execSync('.venv/Scripts/ruff.exe --version', {
    cwd: PROJECT_DIR,
    encoding: 'utf-8',
    timeout: 10000
  });
  console.log('⚠️  Command succeeded (ruff.exe may work)');
} catch (error) {
  console.log('✅ Command failed as expected');
  console.log(`   Error: ${error.message.substring(0, 100)}...`);
}
console.log('');

// Test 3: Trigger Not Found Error
console.log('[TEST 3] Triggering "not found" error...');
console.log('-'.repeat(70));

try {
  execSync('nonexistent_command_12345', {
    cwd: PROJECT_DIR,
    encoding: 'utf-8',
    timeout: 10000
  });
  console.log('⚠️  Command succeeded (unexpected)');
} catch (error) {
  console.log('✅ Command failed as expected');
  console.log(`   Error: ${error.message.substring(0, 100)}...`);
}
console.log('');

// Test 4: Trigger Slow Operation (simulated)
console.log('[TEST 4] Simulating slow operation (>5 min)...');
console.log('-'.repeat(70));

console.log('⚠️  Cannot easily simulate slow operation in test');
console.log('   (Would need to run a command for >5 minutes)');
console.log('');

// Verification
console.log('[VERIFICATION] Checking documentation updates...');
console.log('-'.repeat(70));

// Check AGENTS.md
if (fs.existsSync(agentsPath)) {
  const agentsContent = fs.readFileSync(agentsPath, 'utf-8');
  const agentsLinesAfter = agentsContent.split('\n').length;
  
  if (agentsLinesAfter > agentsLinesBefore) {
    console.log('✅ AGENTS.md was updated');
    console.log(`   Lines: ${agentsLinesBefore} → ${agentsLinesAfter}`);
    
    // Check for "Learned Lessons" section
    if (agentsContent.includes('## Learned Lessons')) {
      console.log('   ✅ Found "Learned Lessons" section');
    }
    
    // Check for encoding rule
    if (agentsContent.includes('encoding="utf-8"')) {
      console.log('   ✅ Encoding rule added');
    }
  } else {
    console.log('⚠️  AGENTS.md was not updated (plugin may not be loaded)');
  }
} else {
  console.log('❌ AGENTS.md not found');
}

// Check RUN_REPORT.md
if (fs.existsSync(reportPath)) {
  const reportContent = fs.readFileSync(reportPath, 'utf-8');
  const reportLinesAfter = reportContent.split('\n').length;
  
  if (reportLinesAfter > reportLinesBefore) {
    console.log('✅ RUN_REPORT.md was updated');
    console.log(`   Lines: ${reportLinesBefore} → ${reportLinesAfter}`);
    
    if (reportContent.includes('## Learning Session')) {
      console.log('   ✅ Found learning session log');
    }
  } else {
    console.log('⚠️  RUN_REPORT.md was not updated');
  }
} else {
  console.log('⚠️  RUN_REPORT.md not found (will be created)');
}

// Check TROUBLESHOOTING.md
if (fs.existsSync(tsPath)) {
  const tsContent = fs.readFileSync(tsPath, 'utf-8');
  
  if (tsContent.includes('| Issue |')) {
    console.log('✅ TROUBLESHOOTING.md has content');
    
    if (tsContent.includes('encoding') || tsContent.includes('PermissionError')) {
      console.log('   ✅ Known issue logged');
    }
  }
} else {
  console.log('⚠️  TROUBLESHOOTING.md not found (will be created)');
}

console.log('');

// Cleanup
console.log('[CLEANUP] Restoring original documentation...');
console.log('-'.repeat(70));

if (backupAgents) fs.writeFileSync(agentsPath, backupAgents);
if (backupReport) fs.writeFileSync(reportPath, backupReport);
if (backupTs) fs.writeFileSync(tsPath, backupTs);

console.log('✅ Restored original files');
console.log('');

// Summary
console.log('='.repeat(70));
console.log('TEST SCENARIO COMPLETE');
console.log('='.repeat(70));
console.log('');
console.log('📝 Notes:');
console.log('   1. Plugin must be loaded in OpenCode for real testing');
console.log('   2. Run "node test-retrospective-plugin.js" to verify structure');
console.log('   3. Run "node simulate-learning-session.js" for workflow demo');
console.log('   4. Restart OpenCode to load the global plugin');
console.log('');
console.log('🔄 To test with live OpenCode:');
console.log('   1. Restart OpenCode');
console.log('   2. Run a failing command');
console.log('   3. Check AGENTS.md for new rules');
console.log('   4. Check RUN_REPORT.md for learning logs');
console.log('='.repeat(70));
