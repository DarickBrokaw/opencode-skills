#!/usr/bin/env node
/**
 * Simulated Learning Session
 * 
 * This script simulates what the retrospective-plugin would do
 * when a failure occurs. It demonstrates the full learning workflow.
 * 
 * Usage: node simulate-learning-session.js
 */

const fs = require('fs');
const path = require('path');

console.log('='.repeat(60));
console.log('RETROSPECTIVE PLUGIN - SIMULATED LEARNING SESSION');
console.log('='.repeat(60));

// Step 1: Simulate a failure occurring
console.log('\n[STEP 1] Simulating a failure event...');

const failureEvent = {
  type: 'tool_failure',
  tool: 'bash',
  exit_code: 1,
  error: 'charmap codec can\'t encode characters in position 0: character maps to <undefined>',
  command: 'python -m ruff check .',
  duration_ms: 2500,
  timestamp: new Date().toISOString()
};

console.log('Event captured:');
console.log(`  - Tool: ${failureEvent.tool}`);
console.log(`  - Command: ${failureEvent.command}`);
console.log(`  - Error: ${failureEvent.error}`);
console.log(`  - Exit code: ${failureEvent.exit_code}`);
console.log('✅ Failure event captured');

// Step 2: Analyze the failure
console.log('\n[STEP 2] Analyzing failure pattern...');

const patterns = [
  {
    match: (e) => e.error?.includes('charmap') || e.error?.includes('encoding'),
    insight: 'Windows subprocess requires explicit UTF-8 encoding',
    rule: 'Always use encoding="utf-8" in subprocess calls on Windows',
    automation_potential: 'high'
  },
  {
    match: (e) => e.error?.includes('PermissionError') || e.error?.includes('Access is denied'),
    insight: 'Direct executables may be blocked by security software',
    rule: 'Use python -m <tool> instead of <tool>.exe on Windows',
    automation_potential: 'medium'
  },
  {
    match: (e) => e.error?.includes('ENOENT') || e.error?.includes('not found'),
    insight: 'Command or file not found',
    rule: 'Verify commands and paths exist before calling them',
    automation_potential: 'none'
  }
];

let detectedPattern = null;
for (const pattern of patterns) {
  if (pattern.match(failureEvent)) {
    detectedPattern = pattern;
    break;
  }
}

if (detectedPattern) {
  console.log('✅ Pattern detected:', detectedPattern.insight);
  console.log('   Rule:', detectedPattern.rule);
  console.log('   Automation potential:', detectedPattern.automation_potential);
} else {
  console.log('⚠️ No known pattern detected');
}

// Step 3: Generate lesson
console.log('\n[STEP 3] Generating lesson...');

const lesson = {
  id: `lesson-${Date.now()}`,
  timestamp: failureEvent.timestamp,
  event: failureEvent,
  insight: detectedPattern?.insight || 'Unknown issue occurred',
  rule: detectedPattern?.rule || 'Manual investigation required',
  automation_potential: detectedPattern?.automation_potential || 'none',
  status: 'pending'
};

console.log('Lesson generated:');
console.log(`  - ID: ${lesson.id}`);
console.log(`  - Insight: ${lesson.insight}`);
console.log(`  - Rule: ${lesson.rule}`);

// Step 4: Update AGENTS.md
console.log('\n[STEP 4] Updating AGENTS.md...');

const agentsPath = path.join(process.cwd(), 'AGENTS.md');
if (fs.existsSync(agentsPath)) {
  const agentsContent = fs.readFileSync(agentsPath, 'utf-8');
  const timestamp = lesson.timestamp.split('T')[0];
  
  const ruleEntry = `\n### Learned on ${timestamp} (Auto-Generated)\n\n`;
  const ruleContent = `1. **${lesson.rule}**\n   - Insight: ${lesson.insight}\n   - Source: ${failureEvent.tool} failure\n   - Automation potential: ${lesson.automation_potential}\n`;
  
  // Find or create Learned Lessons section
  let newContent;
  if (agentsContent.includes('## Learned Lessons')) {
    newContent = agentsContent.replace(
      '## Learned Lessons',
      `## Learned Lessons${ruleEntry}${ruleContent}`
    );
  } else {
    newContent = agentsContent + `\n\n## Learned Lessons\n${ruleEntry}${ruleContent}`;
  }
  
  fs.writeFileSync(agentsPath, newContent);
  console.log('✅ AGENTS.md updated with new rule');
  
  // Show the updated section
  const lines = newContent.split('\n');
  const learnedSectionIndex = lines.findIndex(l => l.includes('## Learned Lessons'));
  if (learnedSectionIndex !== -1) {
    console.log('\nUpdated section:');
    console.log('-'.repeat(40));
    console.log(lines.slice(learnedSectionIndex, learnedSectionIndex + 8).join('\n'));
    console.log('-'.repeat(40));
  }
} else {
  console.log('❌ AGENTS.md not found');
}

// Step 5: Update TROUBLESHOOTING.md
console.log('\n[STEP 5] Updating TROUBLESHOOTING.md...');

const tsPath = path.join(process.cwd(), 'TROUBLESHOOTING.md');
const tsEntry = `| ${failureEvent.error.substring(0, 60)}... | ${lesson.rule} | ${failureEvent.tool} |\n`;

if (fs.existsSync(tsPath)) {
  const tsContent = fs.readFileSync(tsPath, 'utf-8');
  
  // Check if entry already exists
  if (!tsContent.includes(failureEvent.error.substring(0, 30))) {
    const newContent = tsContent.includes('| Issue |')
      ? tsContent.replace('| Issue |', `| ${failureEvent.error.substring(0, 50)}... |\n| Issue |`)
      : tsContent + tsEntry;
    
    fs.writeFileSync(tsPath, newContent);
    console.log('✅ TROUBLESHOOTING.md updated');
  } else {
    console.log('⚠️ Entry already exists in TROUBLESHOOTING.md');
  }
} else {
  // Create new file
  const header = `# Troubleshooting Guide (Auto-Generated)\n\n| Issue | Solution | Category |\n|-------|----------|----------|\n`;
  fs.writeFileSync(tsPath, header + tsEntry);
  console.log('✅ TROUBLESHOOTING.md created');
}

// Step 6: Log to RUN_REPORT.md
console.log('\n[STEP 6] Logging to RUN_REPORT.md...');

const reportPath = path.join(process.cwd(), 'RUN_REPORT.md');
const sessionLog = `\n---\n\n## Learning Session: ${lesson.timestamp}\n\n`;
const sessionContent = `**Type:** Auto-captured from ${failureEvent.tool} failure\n\n` +
  `### Event Details\n` +
  `- **Command:** ${failureEvent.command}\n` +
  `- **Error:** ${failureEvent.error}\n` +
  `- **Exit Code:** ${failureEvent.exit_code}\n\n` +
  `### Lesson Learned\n` +
  `- **Insight:** ${lesson.insight}\n` +
  `- **Rule:** ${lesson.rule}\n` +
  `- **Automation Potential:** ${lesson.automation_potential}\n\n` +
  `### Documentation Updates\n` +
  `- ✅ AGENTS.md: New rule added\n` +
  `- ✅ TROUBLESHOOTING.md: Known issue logged\n`;

if (fs.existsSync(reportPath)) {
  const reportContent = fs.readFileSync(reportPath, 'utf-8');
  fs.writeFileSync(reportPath, reportContent + sessionLog + sessionContent);
  console.log('✅ RUN_REPORT.md updated');
} else {
  fs.writeFileSync(reportPath, `# RUN_REPORT.md\n\n${sessionLog}${sessionContent}`);
  console.log('✅ RUN_REPORT.md created');
}

// Summary
console.log('\n' + '='.repeat(60));
console.log('LEARNING SESSION COMPLETE');
console.log('='.repeat(60));

console.log('\n📊 Summary:');
console.log(`  - Lesson ID: ${lesson.id}`);
console.log(`  - Pattern detected: ${detectedPattern ? 'Yes' : 'No'}`);
console.log(`  - Automation potential: ${lesson.automation_potential}`);
console.log(`  - Documentation updated: AGENTS.md, TROUBLESHOOTING.md, RUN_REPORT.md`);

console.log('\n📝 Next Steps:');
console.log('  1. Review AGENTS.md for the new rule');
console.log('  2. Check TROUBLESHOOTING.md for the known issue');
console.log('  3. The rule will be automatically applied in future runs');
console.log('  4. This prevents the same issue from blocking future work');

console.log('\n🔄 This is what the retrospective-plugin does automatically!');
console.log('   The plugin listens to events and runs this workflow on every failure.');
console.log('='.repeat(60));
