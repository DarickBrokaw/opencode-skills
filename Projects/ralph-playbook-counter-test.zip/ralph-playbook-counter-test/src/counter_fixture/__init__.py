"""Counter fixture package for ralph-playbook verification."""
