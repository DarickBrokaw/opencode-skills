## Project: Counter Fixture (Ralph-loop playbook verification)

### Global Plugin/Skill/Tool Preference
- **Global installations preferred**: Plugins, skills, and tools installed globally (e.g., `%APPDATA%\opencode\plugins\`) are the source of truth
- **Local copies are fallbacks**: Only use local `.opencode/plugins/` if global is unavailable
- **Plugin resolution order**:
  1. Global plugins: `%APPDATA%\opencode\plugins\<plugin-name>\.opencode\plugins\<plugin-name>.ts`
  2. Local singular: `.opencode/plugin/<plugin-name>.ts`
  3. Local plural: `.opencode/plugins/<plugin-name>.ts`
- **When local is missing/stub**: Copy from global location to local, but always reference global as authoritative

### Retrospective Learning Plugin (Global)
- **Location**: `%APPDATA%\opencode\plugins\retrospective-plugin\.opencode\plugins\retrospective-plugin.ts`
- **Purpose**: Automatically captures lessons from failures and updates documentation
- **Events**: `tool.execute.after`, `session.error`, `session.idle`, `file.edited`
- **Documentation**: Updates AGENTS.md, TROUBLESHOOTING.md, RUN_REPORT.md automatically
- **Config**: `.opencode/retrospective-config.json` (project) or global config

### Quick start (Windows PowerShell)
- Create venv: `py -m venv .venv`
- Activate: `.venv\Scripts\Activate.ps1`
- Install: `python -m pip install -U pip && python -m pip install -r requirements.txt`

### Quick start (bash/zsh)
- Create venv: `python -m venv .venv`
- Activate: `source .venv/bin/activate`
- Install: `python -m pip install -U pip && python -m pip install -r requirements.txt`

### Run
- CLI help: `python -m counter_fixture --help`
- Get value: `python -m counter_fixture get`
- Increment once: `python -m counter_fixture inc`
- Drive to target: `python -m counter_fixture run --target 10`

### Validation (must pass before committing in BUILD mode)
- Single command (preferred): `python tools/loopback_check.py`
- Equivalent manual commands:
  - Tests: `python -m pytest`
  - Lint: `python -m ruff check .`
  - Format: `python -m ruff format --check .`

---

## Windows Execution Guidelines (Critical)

### Character Encoding
- **ALWAYS use explicit UTF-8 encoding** for file I/O and subprocess calls
- **AVOID Unicode box-drawing characters** (`━`, `┃`, `━`, `◆`, `→`) in any output, prompts, or subprocess arguments
- **Use ASCII alternatives**:
  - `====` instead of `━━━━`
  - `=== LOOP 1 ===` instead of `━━━━━ LOOP 1 ━━━━━`
  - `PASS`/`FAIL` instead of `✅`/`❌` in subprocess output
- **For Python subprocess**, always specify encoding:
  ```python
  subprocess.run(cmd, encoding='utf-8', text=True)
  ```
- **If encoding issues persist**, use Node.js child_process instead of Python subprocess (better Unicode handling on Windows)

### Execution Workarounds
- **Use Python module invocation** over direct executables:
  - ✅ `python -m ruff` instead of `ruff.exe`
  - ✅ `python -m pytest` instead of pytest executable
  - ✅ `python -m pip` instead of pip executable
- **Use direct venv paths** instead of activation scripts:
  - ✅ `.venv\Scripts\python.exe` instead of `.\.venv\Scripts\Activate.ps1`
  - ✅ `.venv\Scripts\python.exe -m ruff` instead of activating then running ruff
- **Avoid shell/activation scripts** that may fail in different shells:
  - PowerShell scripts may be blocked by Execution Policy
  - Bash cannot run `.ps1` files
  - Cross-shell compatibility is minimal

### PowerShell Barriers
- **PowerShell scripts will likely be blocked** by:
  - Execution Policy (Restricted by default in many environments)
  - ThreatLocker / security software
  - Permission issues on script files
- **Safe alternatives**:
  - Use Node.js runner for automation: `node run_ralph_node.js`
  - Use Python with explicit encoding
  - Use batch files (`.bat`) with `chcp 65001` for UTF-8
- **If PowerShell required**, bypass execution:
  ```powershell
  powershell.exe -ExecutionPolicy Bypass -File script.ps1
  ```

### Plugin Resolution Strategy
- **Global plugins are authoritative**: `%APPDATA%\opencode\plugins\<plugin-name>\.opencode\plugins\<plugin-name>.ts`
- **Check global first**: If local plugin is missing, placeholder, or stub, check global location
- **Copy from global to local**: If using local plugin, copy from global location:
  ```bash
  cp /c/Users/.../.config/opencode/plugins/ralph-loop/.opencode/plugins/ralph-loop.ts .opencode/plugins/ralph-loop.ts
  ```
- **Document plugin source**: Always note in RUN_REPORT.md whether plugin is local or global

### Git Configuration for Windows
- **Set line ending handling** to avoid LF/CRLF warnings:
  ```bash
  git config core.autocrlf input  # Windows recommendation
  # OR
  git config core.autocrlf false  # Disable auto-conversion
  ```
- **Use git add -A && git commit** with descriptive messages per playbook rules

---

## Ralph-loop Specific Notes

### Ralph-loop Plugin Location
- **Primary (global)**: `C:\Users\<user>\.config\opencode\plugins\ralph-loop\.opencode\plugins\ralph-loop.ts`
- **Local fallback**: `.opencode/plugins/ralph-loop.ts`
- **If local is stub/placeholder**: Copy from global location immediately

### Ralph-loop Execution on Windows
- **OpenCode CLI may be blocked**: `opencode.ps1` may fail due to PowerShell/security restrictions
- **Alternative: Node.js runner**: Use `node run_ralph_node.js build <iterations>`
- **Manual execution**: If plugin fails, execute PLAN/BUILD phases manually per PROMPT files
- **Report issues**: Always document execution barriers in RUN_REPORT.md

### Ralph-loop Automation Scripts
- **Preferred**: `run_ralph_node.js` (Node.js - better Windows compatibility)
- **Fallback**: `run_ralph.ps1` (PowerShell - may be blocked)
- **Legacy**: `loop.sh` (Linux/macOS only)
- **Never use**: Direct OpenCode CLI calls on Windows without testing encoding first

---

## Troubleshooting Quick Reference

| Issue | Symptom | Solution |
|-------|---------|----------|
| Unicode encoding error | `charmap codec can't encode/decode` | Use Node.js or explicit UTF-8 encoding |
| PowerShell blocked | `Access to path denied` | Use Node.js runner instead |
| Ruff executable blocked | `PermissionError: WinError 5` | Use `python -m ruff` |
| Plugin is placeholder | Returns `{}` immediately | Copy from global location |
| Venv activation fails | Syntax errors in bash | Use direct paths: `.venv/Scripts/python.exe` |
| Git line ending warnings | `LF will be replaced by CRLF` | Set `git config core.autocrlf input` |
| Subprocess hangs | No output, timeout | Add encoding parameter, use Node.js |
| OpenCode CLI fails | PowerShell security error | Use Node.js automation runner |

---

## Environment Diagnosis

If experiencing issues, run this diagnostic:

```bash
# Check Python and versions
.venv/Scripts/python.exe --version
.venv/Scripts/python.exe -m pytest --version
.venv/Scripts/python.exe -m ruff --version

# Check plugin locations
ls -la .opencode/plugins/
ls -la "$APPDATA/.config/opencode/plugins/ralph-loop/.opencode/plugins/" 2>/dev/null || echo "Global plugin not found"

# Check git config
git config core.autocrlf
git config user.name
git config user.email

# Test subprocess encoding
.venv/Scripts/python.exe -c "import subprocess; r = subprocess.run(['echo', 'test'], capture_output=True, text=True, encoding='utf-8'); print('OK' if r.returncode == 0 else 'FAIL')"

# Verify CLI works
.venv/Scripts/python.exe -m counter_fixture --help
```

Document all findings in RUN_REPORT.md under "Environment Diagnosis".


## Learned Lessons

### Learned on 2026-01-21 (Auto-Generated)

1. **Always use encoding="utf-8" in subprocess calls on Windows**
   - Insight: Windows subprocess requires explicit UTF-8 encoding
   - Source: bash failure
   - Automation potential: high
