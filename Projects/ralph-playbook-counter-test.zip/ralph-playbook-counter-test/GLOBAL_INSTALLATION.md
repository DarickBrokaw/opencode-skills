# Global Plugin Installation - Retrospective Learning System

## ✅ Installation Complete

The retrospective learning plugin has been **moved to global installation** and is now authoritative.

## 📦 Global Locations

### Plugin (Auto-Learning)
```
C:\Users\darick\.config\opencode\plugins\retrospective-plugin\.opencode\plugins\retrospective-plugin.ts
```

Supporting files:
- `C:\Users\darick\.config\opencode\plugins\retrospective-plugin\AGENTS.md`
- `C:\Users\darick\.config\opencode\plugins\retrospective-plugin\opencode.json`

### Skill (Manual Learning)
```
C:\Users\darick\.config\opencode\skills\retrospective-learner\SKILL.md
```

## 🔄 Migration Summary

### Before (Local Installation)
```
ralph-playbook-counter-test/
└── .opencode/
    └── plugins/
        ├── ralph-loop.ts
        └── retrospective-plugin.ts  ← REMOVED
```

### After (Global Installation)
```
ralph-playbook-counter-test/
└── .opencode/
    └── plugins/
        └── ralph-loop.ts  ← Local only (no duplicate)

Global:
C:\Users\darick\.config\opencode\plugins\
├── ralph-loop/
│   └── .opencode/
│       └── plugins/
│           └── ralph-loop.ts
└── retrospective-plugin/  ← NEW
    ├── .opencode/
    │   └── plugins/
    │       └── retrospective-plugin.ts
    ├── AGENTS.md
    └── opencode.json
```

## 📝 Configuration

### Project-Level Config (Optional)
```
ralph-playbook-counter-test/
└── .opencode/
    └── retrospective-config.json  ← Still used for project overrides
```

### Global Config (Optional)
```
C:\Users\darick\.config\opencode\
└── retrospective-config.json
```

## 🔧 How OpenCode Loads Plugins

OpenCode automatically loads plugins from these locations:

1. **Global plugins** (authoritative):
   ```
   %APPDATA%\opencode\plugins\*\.opencode\plugins\*.ts
   ```

2. **Project plugins** (fallback):
   ```
   .opencode/plugins/*.ts
   ```

3. **Local singular** (rare):
   ```
   .opencode/plugin/*.ts
   ```

The retrospective plugin is loaded automatically from global location.

## 📚 Documentation Updated

### AGENTS.md (Project)
Added section about global retrospective plugin:
```markdown
### Retrospective Learning Plugin (Global)
- Location: `%APPDATA%\opencode\plugins\retrospective-plugin\.opencode\plugins\retrospective-plugin.ts`
- Purpose: Automatically captures lessons from failures
- Events: tool.execute.after, session.error, session.idle, file.edited
```

### opencode.json (Project)
Updated to reference global plugin:
```json
"plugins": [
  "ralph-loop"
  // Note: retrospective-plugin is loaded from global installation
]
```

## 🎯 Verification

To verify the global installation:

```bash
# Check global plugin exists
ls -la /c/Users/darick/.config/opencode/plugins/retrospective-plugin/.opencode/plugins/

# Check global skill exists
ls -la /c/Users/darick/.config/opencode/skills/retrospective-learner/

# Verify local project is clean
ls -la .opencode/plugins/  # Should only have ralph-loop.ts
```

## 🚀 Next Steps

1. **Restart OpenCode** to load the global plugin
2. **Test auto-learning** by running a failing command
3. **Verify documentation updates** in AGENTS.md
4. **Check RUN_REPORT.md** for learning session logs

## 📖 Related Documentation

- **LEARNING_SYSTEM.md** - Complete system documentation
- **Global AGENTS.md** - Plugin-specific documentation
- **Skill SKILL.md** - Manual learning skill documentation

## ✅ Benefits of Global Installation

1. **Single source of truth** - One installation, used by all projects
2. **Easy updates** - Update once, applies everywhere
3. **Consistent behavior** - Same learning across all projects
4. **Clean projects** - No duplicate plugin files in projects
5. **Follows AGENTS.md guidelines** - Global installations preferred

---

*Global installation completed: 2026-01-21*
*Plugin: retrospective-plugin v1.0.0*
