#!/usr/bin/env node
/**
 * Test script for retrospective-plugin
 * Simulates OpenCode events and verifies plugin captures them
 */

const fs = require('fs');
const path = require('path');

// Mock context similar to OpenCode
const mockContext = {
  project: {
    name: 'test-project',
    directory: {
      path: process.cwd()
    }
  },
  client: {
    app: {
      log: (msg) => console.log('[LOG]', msg)
    }
  },
  directory: {
    path: process.cwd()
  },
  worktree: '/tmp/test-worktree'
};

// Test 1: Verify plugin file exists and can be loaded
console.log('\n=== TEST 1: Plugin File Exists ===');
const pluginPath = path.join(process.cwd(), '.opencode/plugins/retrospective-plugin.ts');
if (fs.existsSync(pluginPath)) {
  console.log('✅ Plugin file exists:', pluginPath);
  
  // Read and verify structure
  const content = fs.readFileSync(pluginPath, 'utf-8');
  
  // Check for key exports
  if (content.includes('export const RetrospectivePlugin')) {
    console.log('✅ Plugin exports RetrospectivePlugin function');
  } else {
    console.log('❌ Missing RetrospectivePlugin export');
  }
  
  // Check for event handlers
  const eventHandlers = [
    "'tool.execute.after'",
    "'session.error'",
    "'session.idle'",
    "'file.edited'"
  ];
  
  eventHandlers.forEach(handler => {
    if (content.includes(handler)) {
      console.log(`✅ Event handler found: ${handler}`);
    } else {
      console.log(`❌ Missing event handler: ${handler}`);
    }
  });
  
  // Check for lesson generation
  if (content.includes('analyzeEvent') && content.includes('applyLesson')) {
    console.log('✅ Lesson generation functions present');
  } else {
    console.log('❌ Missing lesson generation functions');
  }
  
  // Check for documentation updates
  if (content.includes('updateAgentsMd') && content.includes('updateTroubleshootingMd')) {
    console.log('✅ Documentation update functions present');
  } else {
    console.log('❌ Missing documentation update functions');
  }
  
} else {
  console.log('❌ Plugin file not found:', pluginPath);
}

// Test 2: Verify skill file exists
console.log('\n=== TEST 2: Skill File Exists ===');
const skillPath = path.join(process.cwd(), '.opencode/skills/retrospective-learner/SKILL.md');
if (fs.existsSync(skillPath)) {
  console.log('✅ Skill file exists:', skillPath);
  
  const skillContent = fs.readFileSync(skillPath, 'utf-8');
  
  // Check frontmatter
  if (skillContent.includes('name: retrospective-learner')) {
    console.log('✅ Skill has correct name');
  } else {
    console.log('❌ Skill missing name in frontmatter');
  }
  
  if (skillContent.includes('description:')) {
    console.log('✅ Skill has description');
  } else {
    console.log('❌ Skill missing description');
  }
} else {
  console.log('❌ Skill file not found:', skillPath);
}

// Test 3: Verify configuration exists
console.log('\n=== TEST 3: Configuration Exists ===');
const configPath = path.join(process.cwd(), '.opencode/retrospective-config.json');
if (fs.existsSync(configPath)) {
  console.log('✅ Config file exists:', configPath);
  
  const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  
  if (config.enabled === true) {
    console.log('✅ Plugin is enabled in config');
  } else {
    console.log('❌ Plugin disabled in config');
  }
} else {
  console.log('⚠️ Config file not found (will use defaults):', configPath);
}

// Test 4: Verify plugin is registered in opencode.json
console.log('\n=== TEST 4: Plugin Registered in opencode.json ===');
const opencodePath = path.join(process.cwd(), 'opencode.json');
if (fs.existsSync(opencodePath)) {
  const opencodeConfig = JSON.parse(fs.readFileSync(opencodePath, 'utf-8'));
  
  if (opencodeConfig.plugins && opencodeConfig.plugins.includes('retrospective-plugin')) {
    console.log('✅ Plugin registered in opencode.json');
  } else {
    console.log('❌ Plugin not registered in opencode.json');
  }
  
  if (opencodeConfig.plugins && opencodeConfig.plugins.includes('ralph-loop')) {
    console.log('✅ Ralph-loop plugin also registered');
  }
} else {
  console.log('❌ opencode.json not found');
}

// Test 5: Simulate a failure event
console.log('\n=== TEST 5: Simulate Failure Detection ===');

// Create a mock failure event
const mockFailureEvent = {
  type: 'tool_failure',
  tool: 'bash',
  exit_code: 1,
  error: 'charmap codec can\'t encode characters in position 0',
  duration_ms: 5000,
  timestamp: new Date().toISOString()
};

// Test the analysis logic (simplified)
const analyzeFailure = (event) => {
  if (event.error?.includes('charmap') || event.error?.includes('encoding')) {
    return {
      insight: 'Windows subprocess requires explicit UTF-8 encoding',
      rule: 'Always use encoding="utf-8" in subprocess calls on Windows',
      automation_potential: 'high'
    };
  }
  return null;
};

const result = analyzeFailure(mockFailureEvent);
if (result) {
  console.log('✅ Failure analysis works correctly');
  console.log('   Insight:', result.insight);
  console.log('   Rule:', result.rule);
  console.log('   Automation potential:', result.automation_potential);
} else {
  console.log('❌ Failure analysis did not detect the error');
}

// Test 6: Verify AGENTS.md has Windows guidelines
console.log('\n=== TEST 6: AGENTS.md Has Windows Guidelines ===');
const agentsPath = path.join(process.cwd(), 'AGENTS.md');
if (fs.existsSync(agentsPath)) {
  const agentsContent = fs.readFileSync(agentsPath, 'utf-8');
  
  if (agentsContent.includes('Windows Execution Guidelines')) {
    console.log('✅ AGENTS.md has Windows guidelines');
  } else {
    console.log('❌ AGENTS.md missing Windows guidelines');
  }
  
  if (agentsContent.includes('Character Encoding')) {
    console.log('✅ AGENTS.md has encoding guidelines');
  } else {
    console.log('❌ AGENTS.md missing encoding guidelines');
  }
} else {
  console.log('❌ AGENTS.md not found');
}

console.log('\n=== TEST SUMMARY ===');
console.log('The retrospective-plugin is properly structured.');
console.log('To test auto-learning:');
console.log('1. Restart OpenCode');
console.log('2. Run a failing command (e.g., invalid subprocess)');
console.log('3. Check AGENTS.md for new rules');
console.log('4. Check RUN_REPORT.md for learning session logs');
